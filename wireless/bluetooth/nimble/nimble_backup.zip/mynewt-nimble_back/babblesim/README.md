BabbleSim support for Apache NimBLE
