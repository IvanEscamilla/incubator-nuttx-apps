NimBLE Host GATT Client Reference
---------------------------------

Introduction
~~~~~~~~~~~~

The Generic Attribute Profile (GATT) manages all activities involving services, characteristics, and descriptors. The
client half of the GATT API initiates GATT procedures.

API
~~~~~~

.. doxygengroup:: bt_gatt
    :content-only:
    :members:
